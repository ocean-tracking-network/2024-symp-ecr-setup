
#1.  Setup ####
# - 1.1  Loading packages ####

# Let's load the packages we'll need
#packages for tidying data
library(dplyr) 
library(tidyr)
library(sf)    #loading and working with vector spatial data

# Packages for plotting data
library(ggplot2)

# packages for modelling and visualizing GAMs
library(mgcv)
library(gratia)

# 1.2: Loading the data ####

# Data on the movement of six cod from the bay of the city of Bergen, Norway from July 9th - 18th,
# 2023. Data provided by Robert Lennox (Robert.Lennox@dal.ca), for use for the purposes of this 
# workshop. Do not use this data for other purposes without Robert's permission. 
# Data is from an acoustic telemetry array in the bay, that has been filtered down to observations
# spaced approximately 20 minutes apart from one another in time. 
cod_paths <- read.csv("data/cod_paths.csv") |> 
  mutate(indiv = factor(indiv),
         indiv_burst = factor(indiv_burst)) %>%
  filter(!is.na(speed_ms))

#view columns in data
str(cod_paths)

# the data variables:
# indiv: the individual fish
# x, y: estimated.UTM coordinates of the fish at a given time (units of m).
# x_sd, y_sd, t_sd: standard deviations of location in space (units of m) and time (units of seconds)
# burst: the individual burst of continuously detected movement. 
# indiv_burst: combined factor variable merging individual ID and burst ID
# doy: short for "day of year". Julian date of the observation (doy = 190 is July pth in 2023).
# hour: hour of the day, in hours + decimal fractions of the hour
# shoredist_m: estimated distance to the shore of the bay, in meters
# bottom_depth_m: bottom depth of the bay at the estimated location, in meters
# speed_ms: estimated speed moved from the previously observed step location, in meters per second

#view the data values
head(cod_paths)

# Load the shore boundary
bay_boundary <- st_read("data/bay_boundary.shp")


# 1.3 Visualizing the data ####

# Setting up ggplot

theme_set(theme_bw())


# raw path data
cod_path_plot <- ggplot() + 
  geom_sf(data = bay_boundary, fill = "lightblue", color="grey") +
  geom_path(data = cod_paths, aes(x = x, y = y, group = indiv_burst), color = "black") +
  facet_wrap(~indiv)

print(cod_path_plot)

# Plotting speed versus some of the predictors


speed_vs_shoredist <- ggplot(data = cod_paths, aes(x = shoredist_m, y = speed_ms)) +
  geom_point()+
  facet_wrap(~indiv) + 
  labs(x = "shore distance (m)",
       y = "Movement speed (m/s)")

print(speed_vs_shoredist) 


speed_vs_bottom <- ggplot(data = cod_paths, aes(x = shoredist_m, y = speed_ms)) +
  geom_point() + 
  facet_wrap(~indiv) + 
  labs(x = "Bottom depth (m)",
       y = "Movement speed (m/s)")

print(speed_vs_bottom)

speed_vs_hour <- ggplot(data = cod_paths, aes(x = hour, y = speed_ms)) +
  geom_point()+ 
  facet_wrap(~indiv) + 
  labs(x = "Time of day (hours)",
       y = "Movement speed (m/s)")

print(speed_vs_hour) 

speed_vs_indiv <- ggplot(data = cod_paths, aes(x = indiv, y = speed_ms)) +
  geom_point() + 
  labs(x = "Individual",
       y = "Movement speed (m/s)")

print(speed_vs_indiv) 

# 2. Modelling movement speed ####

# 2.1 simple linear model of speed vs. depth ####

# Let's start by modelling swimming speed as a linear function of bottom depth

# Remember: in general, it's best to use method = "REML" (although here it does not matter, since
# we don't have any smooth terms
swim_linear1 <- gam(speed_ms ~ shoredist_m + indiv, data = cod_paths, method = "REML")

print(summary(swim_linear1))

# We can visualize the estimated term by using draw from the gratia package: 
#parametric = TRUE means we want to draw the "fixed" effects as well (which is all we have right
#now)
draw(swim_linear1, parametric =  TRUE)

# We can view the fitted curve for this by extracting the predicted values and standard errors from
# the model using the fitted_values function from gratia:

swim_linear1_fit <- fitted_values(swim_linear1)

head(swim_linear1_fit)

#plot the fitted curves on the data
swim_linear1_plot <- speed_vs_shoredist + 
  geom_ribbon(data = swim_linear1_fit, 
              aes(y = .fitted, ymin = .lower_ci, ymax = .upper_ci),
              alpha = 0.25,
              fill = "red") + 
  geom_line(data = swim_linear1_fit,aes(y = .fitted), 
            color ="red") 

print(swim_linear1_plot)

# Let's look at a diagnostic plot for this model using the `appraise()` function from gratia:
appraise(swim_linear1)

# One issue we're dealing with: raw speed is likely poorly modelled with a Gaussian w/ constant
# variance. Let's try log-transforming the prior plot to see this.

swim_linear1_plot + scale_y_log10()

# 2.2 Using a family to model the data ####

# Since speed is bounded below by 0, and is definitely long-tailed, it could make sense to model 
# it using a Gamma distribution. Let's try updating our model from before to use the Gamma family
# with a log-link function

swim_linear2 <- gam(speed_ms ~ shoredist_m + indiv, 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

print(summary(swim_linear2))

draw(swim_linear2,parametric = TRUE)

swim_linear2_fit <- fitted_values(swim_linear2)

swim_linear2_plot <- speed_vs_shoredist + 
  scale_y_log10() + 
  geom_ribbon(data = swim_linear2_fit, 
              aes(y = .fitted, ymin = .lower_ci, ymax = .upper_ci),
              alpha = 0.25,
              fill = "red") + 
  geom_line(data = swim_linear2_fit,aes(y = .fitted), 
            color ="red") 

print(swim_linear2_plot)

# Better residuals, but the linear model is still not ideal here.
appraise(swim_linear2)

# 2.3 Modelling the estimated effect of bottom depth with a smoother
swim_smooth1 <- gam(speed_ms ~ s(shoredist_m, k = 10) + indiv, 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

print(summary(swim_smooth1))

#residuals = TRUE adds the partial residuals (fitted val + deviance residuals) onto each estimated
#smoother. rug = FALSE avoids drawing all the data points as a rug plot (which can be slow)
draw(swim_smooth1, parametric = TRUE, residuals = TRUE, rug = FALSE)

swim_smooth1_fit <- fitted_values(swim_smooth1)

swim_smooth1_plot <- speed_vs_shoredist + 
  scale_y_log10() + 
  geom_ribbon(data = swim_smooth1_fit, 
              aes(y = .fitted, ymin = .lower_ci, ymax = .upper_ci),
              alpha = 0.25,
              fill = "red") + 
  geom_line(data = swim_smooth1_fit,aes(y = .fitted), 
            color ="red") 

print(swim_smooth1_plot)

# 2.4 Varying the number of basis functions ####

#what happens to the fitted model if we change the number of basis functions?

#fewer basis functions: using 3 basis functions instead of 9
swim_smooth1_k4 <- gam(speed_ms ~ s(shoredist_m, k = 4) + indiv, 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

draw(swim_smooth1_k4, rug = FALSE)

#more basis functions: using 19 basis functions instead of 9
swim_smooth1_k20 <- gam(speed_ms ~ s(shoredist_m, k = 20) + indiv, 
                     data = cod_paths, 
                     method = "REML", 
                     family = Gamma(link = "log"))

draw(swim_smooth1_k20, rug = FALSE) 

#compare the estimated smooth curves for the three levels of complexity
basis_comparison <- compare_smooths(swim_smooth1,
                                    swim_smooth1_k4,
                                    swim_smooth1_k20,
                                    select = "s(shoredist_m)")
draw(basis_comparison)




## Exercise 1: fitting a model of speed versus shore distance ####

#Modify the code below to model speed as a function of bottom depth (bottomdepth_m) with 5 basis
#functions
speed_smooth_bottom <- gam(speed_ms ~ s(<variable>, k = <k value>) + indiv,
                        data = cod_paths, 
                        method = "REML")

# Print a summary of your fitted model
<function name1>(speed_smooth_bottom)

# plot the fitted model including parametric effects
<Function name2>(speed_smooth_bottom, parametric = TRUE)


#### This is the start of part 2 of the workshop; Once we have covered the theory for part II, we
#### will start with this section.

# 3. Understanding penalties and multiple smoothers ####

# 3.1 Effects of smoothing parameters on the fitted curve ####

# no penalization
swim_smooth1_s0 <- gam(speed_ms ~ s(shoredist_m, k = 10, sp = 0) + indiv, 
                        data = cod_paths, 
                        method = "REML", 
                        family = Gamma(link = "log"))

draw(swim_smooth1_s0, rug = FALSE)


swim_smooth1_s10 <- gam(speed_ms ~ s(shoredist_m, k = 10, sp = 10) + indiv, 
                          data = cod_paths, 
                          method = "REML", 
                          family = Gamma(link = "log"))

draw(swim_smooth1_s10, rug = FALSE)

swim_smooth1_s500 <- gam(speed_ms ~ s(shoredist_m, k = 10, sp = 500) + indiv, 
                        data = cod_paths, 
                        method = "REML", 
                        family = Gamma(link = "log"))

draw(swim_smooth1_s500)

#show the three models together
compare_smooths(swim_smooth1, 
                swim_smooth1_s0, 
                swim_smooth1_s10, 
                swim_smooth1_s500, 
                select = "s(shoredist_m)") |>
  draw(se = FALSE)

# 3.2 Extending the fitted model with more smoothers

# 3.2.1 Adding random effects as smoothers ####

# Turning our estimates of individual speeds into a random effect
swim_smooth2 <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                      s(indiv, bs = "re"), 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

summary(swim_smooth2)

draw(swim_smooth2, parametric = TRUE, rug = FALSE)


# 3.2.2 Adding a cyclic smoother for time of day ####

# Turning our estimates of individual speeds into a random effect
swim_smooth3 <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                      s(indiv, bs = "re") + 
                      s(hour, k = 6, bs= "cc"), 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

summary(swim_smooth3)


#We will show this with the rug plot so we can see the data distribution
draw(swim_smooth3, parametric = TRUE)

## Exercise 2: extending the model ####

# Change the swim_smooth model to use an adaptive smoother (bs ="ad") with 9 basis functions,instead
# of the default thin plate spline we have been using so far


swim_smooth3a <- gam(speed_ms ~ s(shoredist_m, k = <value>, bs = <value>) + 
                      s(indiv, bs = "re") + 
                      s(hour, k = 6, bs= "cc"), 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

draw(swim_smooth3a, rug = FALSE)


## 3.3 2-dimensional smoothers ####

## 3.3.1 Isotropic smoothers ####

#The first model we will look at is an isotropic smoother. we're setting k for the 2D smoother 
#relatively low so it runs quicker
swim_smooth_isotropic <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                      s(indiv, bs = "re") + 
                      s(hour, k = 6, bs= "cc") + 
                      s(x, y, k=30), 
                    data = cod_paths, 
                    method = "REML", 
                    family = Gamma(link = "log"))

summary(swim_smooth_isotropic)

#notice the change in the estimated shape and significance of the shore distance effect
draw(swim_smooth_isotropic)


## 3.3.2 tensor-product (interaction) smoothers ####

# We use tensor-product smoothers when we want to model interactions between terms that differ 
# in units. Here we might want to see if day-night movement patterns change over the study period
swim_smooth_tensor <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                            s(indiv, bs = "re") +
                            te(doy, hour,  k = c(6,6)), 
                          data = cod_paths, 
                          method = "REML", 
                          family = Gamma(link = "log"))

summary(swim_smooth_tensor)
draw(swim_smooth_tensor)

## 3.3.3 factor-smooth (HGAM) models for modelling individual-level variation ####

# This would be a S-type model, using the nomenclature from Pedersen et al. 2024
swim_smooth_hgam <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                          s(hour, indiv, bs = "fs", xt = list(bs = "cc"),  k = 6),  
                          data = cod_paths, 
                          method = "REML", 
                          family = Gamma(link = "log"))

summary(swim_smooth_hgam)
draw(swim_smooth_hgam)


# We can also build a smoother that includes an overall effect as well as individual-level variation
# this is a GS model using the Pedersen et al. terminology
swim_smooth_hgam2 <- gam(speed_ms ~ s(shoredist_m, k = 6) + 
                        s(hour, bs = "cc", k =6) + 
                        s(hour, indiv, bs = "sz", xt = list(bs = "cc"),  k = 6),  
                      data = cod_paths, 
                      method = "REML", 
                      family = Gamma(link = "log"))

summary(swim_smooth_hgam2)
draw(swim_smooth_hgam2)



